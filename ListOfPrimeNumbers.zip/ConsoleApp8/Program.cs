﻿using System;

namespace ConsoleApp8 // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool isPrime = true;
            List<int> PrimeNumber = new List<int>();
            for(int i=2; i<=100; i++)
            {
                for(int j=2;j<=100; j++)
                {
                    if(i!=j && i%j==0)
                    isPrime = false;
                    break;
                }
                if (isPrime)
                {
                    PrimeNumber.Add(i);
                }
                isPrime = true;
            }
            for (int i = 0; i < PrimeNumber.Count; i++)
            {
                Console.WriteLine(PrimeNumber[i]);
            }

        }
    }
}
